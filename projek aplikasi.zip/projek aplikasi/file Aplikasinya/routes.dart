import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/absensi_screen.dart';
import 'screens/penggajian_screen.dart';

final Map<String, WidgetBuilder> appRoutes = {
  '/home': (context) => const HomeScreen(),
  '/absensi': (context) => const AbsensiScreen(),
  '/penggajian': (context) => const PenggajianScreen(),
};
