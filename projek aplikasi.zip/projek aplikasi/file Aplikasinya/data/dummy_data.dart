final absensiDummy = [
  {
    'nama': 'Ahmad Wijaya',
    'tanggal': '2 Desember 2025',
    'status': 'Hadir'
  },
  {
    'nama': 'Budi Santoso',
    'tanggal': '2 Desember 2025',
    'status': 'Terlambat'
  },
];

final gajiDummy = [
  {'nama': 'Ahmad Wijaya', 'total': 6300000},
  {'nama': 'Siti Nurhaliza', 'total': 6450000},
];
