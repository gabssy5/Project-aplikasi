import 'package:flutter/material.dart';
import 'routes.dart';
import 'theme.dart';
import 'screens/login_screen.dart';


void main() {
runApp(const AbsensiApp());
}


class AbsensiApp extends StatelessWidget {
const AbsensiApp({super.key});


@override
Widget build(BuildContext context) {
return MaterialApp(
debugShowCheckedModeBanner: false,
title: 'Sistem Absensi',
theme: appTheme,
home: const LoginScreen(),
routes: appRoutes,
);
}
}

