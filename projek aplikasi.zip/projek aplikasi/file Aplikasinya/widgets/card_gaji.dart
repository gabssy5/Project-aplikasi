import 'package:flutter/material.dart';

class CardGaji extends StatelessWidget {
  final String nama;
  final String periode;
  final int total;
  final int pokok;
  final int tunjangan;
  final int bonus;
  final int potongan;

  const CardGaji({super.key,
    required this.nama,
    required this.periode,
    required this.total,
    required this.pokok,
    required this.tunjangan,
    required this.bonus,
    required this.potongan,
  });

  Widget infoTile(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: color.withOpacity(0.1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(nama, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                Text("Rp $total", style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 4),
            Text(periode, style: TextStyle(color: Colors.grey.shade700)),
            const SizedBox(height: 10),

            infoTile("Gaji Pokok", "Rp $pokok", Colors.blue),
            const SizedBox(height: 6),
            infoTile("Tunjangan", "Rp $tunjangan", Colors.green),
            const SizedBox(height: 6),
            infoTile("Bonus", "Rp $bonus", Colors.purple),
            const SizedBox(height: 6),
            infoTile("Potongan", "Rp $potongan", Colors.red),
          ],
        ),
      ),
    );
  }
}