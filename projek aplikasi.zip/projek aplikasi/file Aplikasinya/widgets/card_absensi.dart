import 'package:flutter/material.dart';

class CardAbsensi extends StatelessWidget {
  final String nama;
  final String tanggal;
  final String status;
  final String jamMasuk;
  final String jamKeluar;

  const CardAbsensi({super.key,
    required this.nama,
    required this.tanggal,
    required this.status,
    required this.jamMasuk,
    required this.jamKeluar,
  });

  Color getStatusColor() {
    if (status == "Hadir") return Colors.green;
    if (status == "Terlambat") return Colors.orange;
    return Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      color: getStatusColor().withOpacity(0.08),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(nama, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: getStatusColor(),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(status, style: const TextStyle(color: Colors.white)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(tanggal, style: TextStyle(color: Colors.grey.shade700)),
            const SizedBox(height: 6),
            Text("Masuk: $jamMasuk | Keluar: $jamKeluar"),
          ],
        ),
      ),
    );
  }
}