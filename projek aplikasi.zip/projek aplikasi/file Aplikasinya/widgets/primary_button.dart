import 'package:flutter/material.dart';


class PrimaryButton extends StatelessWidget {
final String title;
final VoidCallback onPressed;


const PrimaryButton({super.key, required this.title, required this.onPressed});


@override
Widget build(BuildContext context) {
return SizedBox(
width: double.infinity,
child: ElevatedButton(
style: ElevatedButton.styleFrom(
padding: const EdgeInsets.symmetric(vertical: 14),
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
),
onPressed: onPressed,
child: Text(title, style: const TextStyle(fontSize: 16)),
),
);
}
}