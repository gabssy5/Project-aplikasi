import 'package:flutter/material.dart';


final ThemeData appTheme = ThemeData(
primarySwatch: Colors.blue,
inputDecorationTheme: InputDecorationTheme(
border: OutlineInputBorder(
borderRadius: BorderRadius.circular(10),
),
),
);