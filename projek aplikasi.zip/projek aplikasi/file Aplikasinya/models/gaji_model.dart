class GajiModel {
  final String nama;
  final String periode;
  final int pokok;
  final int tunjangan;
  final int bonus;
  final int potongan;

  int get total => pokok + tunjangan + bonus - potongan;

  GajiModel({
    required this.nama,
    required this.periode,
    required this.pokok,
    required this.tunjangan,
    required this.bonus,
    required this.potongan,
  });
}