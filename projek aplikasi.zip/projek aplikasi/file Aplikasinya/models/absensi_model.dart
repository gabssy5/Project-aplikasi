class AbsensiModel {
  final String nama;
  final String tanggal;
  final String jamMasuk;
  final String jamKeluar;
  final String status;

  AbsensiModel({
    required this.nama,
    required this.tanggal,
    required this.jamMasuk,
    required this.jamKeluar,
    required this.status,
  });
}