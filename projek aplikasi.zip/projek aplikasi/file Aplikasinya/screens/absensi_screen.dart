import 'package:flutter/material.dart';

class AbsensiScreen extends StatelessWidget {
  const AbsensiScreen({super.key});

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> dataAbsensi = [
      {
        "nama": "Ahmad",
        "tanggal": "8/12/2025",
        "status": "Hadir",
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Absensi")),
      body: ListView(
        children: dataAbsensi.map((e) {
          return ListTile(
            title: Text(e['nama'] ?? ''),
            subtitle: Text(e['tanggal'] ?? ''),
            trailing: Text(e['status'] ?? ''),
          );
        }).toList(),
      ),
    );
  }
}
