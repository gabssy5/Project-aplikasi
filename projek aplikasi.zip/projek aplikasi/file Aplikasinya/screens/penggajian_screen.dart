import 'package:flutter/material.dart';

class PenggajianScreen extends StatelessWidget {
  const PenggajianScreen({super.key});

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> dataGaji = [
      {
        "nama": "Ahmad",
        "periode": "Desember",
        "total": "Rp 6.300.000"
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Penggajian")),
      body: ListView(
        children: dataGaji.map((g) {
          return ListTile(
            title: Text(g['nama'] ?? ''),
            subtitle: Text(g['periode'] ?? ''),
            trailing: Text(g['total'] ?? ''),
          );
        }).toList(),
      ),
    );
  }
}
